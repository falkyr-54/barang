<?php
$id_user       = $this->session->userdata('id');
$id_satker     = $this->session->userdata('id_satker');
$konfigurasi  = $this->konfigurasi_model->listing();
$user_detail  = $this->user_model->detail($id_user);

// print_r($expired1bulan);
// echo "<pre>";
// print_r($expired3bulan);
// echo "</pre>";


?>
<header class="main-header">
  <!-- Logo -->
  <a href="<?php echo base_url('admin/dasbor') ?>" class="logo">
    <!-- mini logo for sidebar mini 50x50 pixels -->
    <span class="logo-mini"><?php echo $konfigurasi['namaweb'] ?></span>
    <!-- logo for regular state and mobile devices -->
    <span class="logo-lg"><?php echo $konfigurasi['namaweb'] ?></span>
  </a>
  <!-- Header Navbar: style can be found in header.less -->
  <nav class="navbar navbar-static-top" role="navigation">
    <!-- Sidebar toggle button-->
    <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
      <span class="sr-only">Toggle navigation</span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </a>
    <div class="navbar-custom-menu">
      <ul class="nav navbar-nav">

        <!-- Notifications Mendekati Expired -->
        <li class="dropdown messages-menu">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">
            <i class="fa fa-envelope-o" style="margin-right: 5px;"> <span class="badge  label-danger" style="margin-bottom: 15px;"><?php echo count($expired1bulan) + count($expired3bulan) + count($expired6bulan); ?></span> </i> Obat yang Mendekati Expired
          </a>
          <ul class="dropdown-menu">
            <!-- 6 Bulan   -->
            <li class="header p-2">Ada
              <?php
              // ================ EXP 6 bulan=================
              echo count($expired1bulan);
              ?>
              Obat yang mendekati <br> <span class="label label-default">Expired 1 Bulan lagi</span></li>
            <li>
              <!-- inner menu: contains the actual data -->
              <div class="list-group">
                <?php
                //jika id_jenis hanya 14,15,16
                foreach ($expired1bulan as $exp) {
                ?>
                  <a href="#" class="list-group-item list-group-item-default" style="border-bottom: 2px solid #ccc;">
                    <div class="row">
                      <div class="col-md-6">
                        <h5 class="list-group-item-heading">Nama Obat : </h5>
                        <h5 class="list-group-item-text">Tanggal Expired : </h5>
                      </div>
                      <div class="col-md-6">
                        <h5 class="list-group-item-heading"><?php echo $exp['nama_barang'] ?></h5>
                        <h5 class="list-group-item-text"><?php
                                                          $date =  $exp['tanggal_expired'];
                                                          echo date("d F Y", strtotime($date));
                                                          ?></h5>
                      </div>
                    </div>
                  </a>
                <?php
                } ?>
              </div>
            </li>

            <li class="header">Ada
              <?php
              // ================ EXP 3 bulan=================
              echo count($expired3bulan);
              ?>
              Obat yang mendekati <br><span class="label label-success">Expired 3 Bulan lagi</span></li>
            <div class="list-group">
              <?php
              //jika id_jenis hanya 14,15,16
              foreach ($expired3bulan as $expired3) {
              ?>
                <a href="#" class="list-group-item list-group-item-success" style="border-bottom: 2px solid #5cb85c;">
                  <div class="row">
                    <div class="col-md-6">
                      <h5 class="list-group-item-heading">Nama Obat : </h5>
                      <h5 class="list-group-item-text">Tanggal Expired : </h5>
                    </div>
                    <div class="col-md-6">
                      <h5 class="list-group-item-heading"><?php echo $expired3['nama_barang'] ?></h5>
                      <h5 class="list-group-item-text"><?php
                                                        $date =  $expired3['tanggal_expired'];
                                                        echo date("d F Y", strtotime($date));
                                                        ?></h5>
                    </div>
                  </div>
                </a>
              <?php
              } ?>
            </div>
        </li>
        <li class="header">Ada
          <!-- =============== EXP 1 Bulan ================ -->
          <?= count($expired6bulan); ?>
          Obat yang mendekati <br> <span class="label label-danger">Expired 6 Bulan lagi</span>
        </li>
        <li>
          <!-- PEGAWAI JFU -->
          <div class="list-group">
            <?php
            //jika id_jenis hanya 14,15,16
            foreach ($expired6bulan as $expired6) {
            ?>
              <a href="#" class="list-group-item list-group-item-danger" style="border-bottom: 2px solid #f00;">
                <div class="row">
                  <div class="col-md-6">
                    <h5 class="list-group-item-heading">Nama Obat : </h5>
                    <h5 class="list-group-item-text">Tanggal Expired : </h5>
                  </div>
                  <div class="col-md-6">
                    <h5 class="list-group-item-heading"><?php echo $expired6['nama_barang'] ?></h5>
                    <h5 class="list-group-item-text"><?php
                                                      $date =  $expired6['tanggal_expired'];
                                                      echo date("d F Y", strtotime($date));
                                                      ?></h5>
                  </div>
                </div>
              </a>
            <?php
            } ?>
          </div>
        </li>
        <li class="footer"><a href="">Lihat semua</a></li>
      </ul>
      </li>
      <!-- ================================= -->

      <li class="dropdown user user-menu">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
          <img src="<?php echo base_url() ?>assets/admin/dist/img/ukm.png" class="img-circle" alt="<?php echo $user_detail['nama_user'] ?>" style="height:30px; width: 30px;">
          <span class="hidden-xs"><?php echo $user_detail['nama_user'] ?></span>
        </a>
        <ul class="dropdown-menu">
          <!-- User image -->
          <li class="user-header">
            <img src="<?php echo base_url() ?>assets/admin/dist/img/ukm.png" class="img-circle" alt="<?php echo $user_detail['nama_user'] ?>">
            <p>
              <?php echo $user_detail['nama_user'] ?>
              <small>Nama Account: <?php echo $user_detail['username'] ?></small>
            </p>
          </li>
          <!-- Menu Footer-->
          <li class="user-footer">

            <div class="pull-right">
              <a href="<?php echo base_url('login/logout') ?>" class="btn btn-primary btn-flat"><i class="fa fa-sign-out"></i> Logout</a>
            </div>
          </li>
        </ul>
      </li>
      </ul>
    </div>
  </nav>
</header>