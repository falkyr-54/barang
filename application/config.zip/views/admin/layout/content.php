<?php
// Memanggil tampilan permodul
if( $isi ) {
	$this->load->view($isi);
}