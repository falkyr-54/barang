<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Satker extends CI_Controller {
	// Fungsi database
	public function __construct() {
		parent::__construct();
		$this->load->model('satker_model');
		
	}

	// Pengguna
	public function index() 
	{
		
		$satker=$this->satker_model->listing();

		// Validasi
		$valid = $this->form_validation;
		
		$valid->set_rules('nama_satker','satker','required',
			array(	'required'		=> 'satker harus diisi'));

		$valid->set_rules('alamat','Alamatnya','required',
			array(	'required'		=> 'Alamatnya harus diisi'));
		
		if($valid->run() === FALSE) 
		{
			$data = array(	
				'title'			=> 'Data Master satker',
				'satker'	    =>	$satker,
				'isi'			=> 'admin/satker/list');
			$this->load->view('admin/layout/wrapper',$data);
		}
	}


	public function tambah()
	{
		$satker=$this->satker_model->listing();

		// Validasi
		$valid = $this->form_validation;
		
		$valid->set_rules('nama_satker','satker','required',
			array(	'required'		=> 'satker harus diisi'));

		$valid->set_rules('alamat','Alamatnya','required',
			array(	'required'		=> 'Alamatnya harus diisi'));
		
		if($valid->run() === FALSE) 
		{
			$data = array(	
				'title'			=> 'Tambah data',
				'satker'	    =>	$satker,
				'isi'			=> 'admin/satker/tambah');
			$this->load->view('admin/layout/wrapper',$data);
		}else{
			$i = $this->input;
			$data = array(
				'nama_satker' => $i->post('nama_satker'),
				'alamat'	  => $i->post('alamat'),
				'telepon'	  => $i->post('telepon'),
				'email'	  	  => $i->post('email')
			);
			$this->satker_model->tambah($data);
			$this->session->set_flashdata('sukses', 'Data disimpan');
			redirect(base_url('admin/satker/'));

		}
	}


	public function edit($id_satker)
	{
		$satker = $this->satker_model->detail($id_satker);

		$valid = $this->form_validation;

		$valid->set_rules('nama_satker','satker','required',
			array(	'required'		=> 'satker harus diisi'));

		$valid->set_rules('alamat','Alamatnya','required',
			array(	'required'		=> 'Alamatnya harus diisi'));

		
		if ($valid->run()===FALSE) 
		{
			$data = array(
				'title'		=> 'Ubah Data',
				'satker'	=> $satker,
				'isi'		=> 'admin/satker/edit');
			$this->load->view('admin/layout/wrapper',$data);

		}else{
			$i 	= $this->input;
			$data = array(	'id_satker'		=> $id_satker,
				'nama_satker'	=> $i->post('nama_satker'),
				'alamat'		=> $i->post('alamat'),
				'telepon'		=> $i->post('telepon')
			);
			
			$this->satker_model->edit($data);
			$this->session->set_flashdata('sukses','Data berhasil diubah');
			redirect(base_url('admin/satker'));
		}
	}

	public function delete($id_satker) {
		$data = array('id_satker'	=> $id_satker);
		$this->satker_model->delete($data);
		$this->session->set_flashdata('sukses','Data telah dihapus');
		redirect(base_url('admin/satker'));
	}


}

