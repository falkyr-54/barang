<?php
class Api extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Pegawai_barang_model');
        header('Access-Control-Allow-Origin: *');
        header('Content-Type: application/json; charset=UTF-8');
    }

    public function get_aktif_only()
    {
        $data = $this->Pegawai_barang_model->get_aktif_only();
        echo json_encode([
            'status' => 'success',
            'data' => $data
        ]);
    }
}
