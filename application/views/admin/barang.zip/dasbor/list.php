<?php
$site		= $this->konfigurasi_model->listing();
$id_user	= $this->session->userdata('id');
$user_aktif	= $this->user_model->detail($id_user);

?>
<script src="<?php echo base_url() ?>assets/charts/amcharts/amcharts.js" type="text/javascript"></script>

  
<hr>
<div class="alert alert-success">
<p>Hai <strong><?php echo $user_aktif['nama_user'].' ('.$user_aktif['username'].')'; ?></strong>. Selamat datang di <strong><?php echo $site['namaweb'].' - '.$site['tagline'] ?></strong></p>
</div>

<script src="<?php echo base_url() ?>assets/charts/amcharts/amcharts.js" type="text/javascript"></script>
<div class="clearfix"></div>



<!-- /.row -->
<div class="row"><br><br>
<div class="col-md-12">
</div>
</div>
<!-- /.row -->



